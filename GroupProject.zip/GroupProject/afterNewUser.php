<!doctype html>
<html>
    <head>
        <meta charset="UTF-8" />
        <title>Group Project </title>
        <link rel="stylesheet" href="terpShopping.css" />

    </head>

    <body background = "2.jpg">
    <img src="umcp.png" name="umcp" style='width: 5em;position: relative; left: 200px;top:60px'>
    <h1>Phone Shopping</h1>
    <img src="umcp.png" name="umcp" style='width: 5em;position: relative; left: 870px;top:60px'>
    <hr><hr>
    <form action="next1.php" method="post">
    <input type="submit" name="signIn" value="Signin">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <input type="submit" name="newUser" value="New User">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <input type="submit" name="contact" value="Contact">
    <hr><hr>
    </form>

    <h3>Welcome to our Phone Shopping System</h3>
    <h3>Please click Singin to login to your account</h3><br>

    <img src="smile.png" name="smile" style='width:10em; position: relative; left: 550px;'>
    </body>
</html>

