<html>
    <head>
        <meta charset="UTF-8" />
        <title>Group Project </title>
        <link rel="stylesheet" href="terpShopping.css" />
    </head>

    <body background = "2.jpg">
    <img src="umcp.png" name="umcp" style='width: 5em;position: relative; left: 200px;top:60px'>
    <h1>Phone Shopping </h1>
    <img src="umcp.png" name="umcp" style='width: 5em;position: relative; left: 870px;top:60px'>
    <hr><hr>
    <input type="submit" name="buy" value="Buy items" style='position:relative; left: 22em' onclick="window.location.href='list.php'">    
    <input type ="submit" name="sell" value="Sell items" style='position:relative; left: 26em' onclick="window.location.href='sell.php'">
    <input type="submit" name="delete" value="Delete items" style='position:relative; left: 31em' onclick="window.location.href='delete.php'">
    <input type="submit" name="logout" value="Logout" style='position:relative; left: 37em' onclick="window.location.href='terpshopping.html'">
    <hr><hr>
    </body>
</html>
